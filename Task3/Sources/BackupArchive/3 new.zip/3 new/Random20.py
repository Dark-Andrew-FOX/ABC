import random


def random20():
    return random.randint(1, 20)
